package it.polito.hotel.gui;

import it.polito.hotel.HotelModel;
import it.polito.hotel.bean.Reservation;
import it.polito.hotel.bean.Room;
import it.polito.hotel.dao.HotelDAO;

import java.net.URL;
import java.sql.Date;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.util.Arrays;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import jfxtras.labs.scene.control.CalendarTextField;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;

public class Controller {
	
	private HotelModel hotel;
	
	
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private CalendarTextField arrivo;

    @FXML
    private Button btnCalcola;

    @FXML
    private Button btnPrenota;

    @FXML
    private Group date;
    
    @FXML
    private BarChart<String,Number> bar;

    @FXML
    private ComboBox<String> extra;

    @FXML
    private TextField family;
    
    @FXML
    private ComboBox<Integer> ospiti;

    @FXML
    private CalendarTextField partenza;

    @FXML
    private Group prenotazione;

    @FXML
    private TextArea txtArea;
    private Date arrival;
    private Date departure;
    private List<Room>allFreeRooms;


    @FXML
    void doCalcola(ActionEvent event) {
    	arrival= new Date(arrivo.getValue().getTimeInMillis());
    	departure = new Date(partenza.getValue().getTimeInMillis());
    
    	txtArea.clear();
    	if(arrival.before(departure)){
    		
          allFreeRooms= hotel.calcolaFree(arrival, departure);
          
			if (allFreeRooms.isEmpty()){
				txtArea.appendText("Non ci sono camere disponibili nel periodo indicato");
				
			}
			else{
				Collections.sort(allFreeRooms);
				txtArea.appendText("CAMERE DISPONIBILI:\n");
				txtArea.appendText("\n");
				for (Room r : allFreeRooms) {
					
					txtArea.appendText(r.getIdCamera()+ " con " + r.getLetti()
							+ " posti disponibili;\n");
				}
				prenotazione.setDisable(false);
				date.setDisable(true);
			}

	    	 

		}
    	else {
    		
    		txtArea.appendText("ATTENZIONE! la data di partenza � uguale o precedente alla data di arrivo");
    	}

    }

    @FXML
    void doPrenota(ActionEvent event) {
    	HotelDAO dao =new HotelDAO();
    	txtArea.clear();
		int t=0;
		if(family.getText().isEmpty()){
			txtArea.appendText("Inserire cognome \n");
			t++;
		}
		if(ospiti.getValue()==null){
			txtArea.appendText("Inserire numero ospiti\n");
			t++;
		}
		if(extra.getValue()==null){
			txtArea.appendText("Inserire tipologia camera\n");
			t++;
		}
		if(t==0){
			List<Reservation> r = hotel.addPrenotazione(family.getText(), arrival, departure, ospiti.getValue(), extra.getValue());
			
			if(!r.isEmpty()){
				txtArea.appendText("PRENOTAZIONE AVVENUTA. Camere assegnate: \n");
				txtArea.appendText("\n");
				for(Reservation i : r){
					txtArea.appendText(i.getRoom().getIdCamera()+" con "+i.getRoom().getLetti()+" letti disponibili;\n");
					dao.addReservation(i);
				}
				updateChart();	
				startCondition();
			}
			else
				txtArea.appendText("PRENOTAZIONE NON AVVENUTA! Il numero di persone supera la disponibilit� delle camere");
		}
		
		
    }

    @FXML
    void initialize() {
        assert arrivo != null : "fx:id=\"arrivi\" was not injected: check your FXML file 'altro.fxml'.";
        assert btnCalcola != null : "fx:id=\"btnCalcola\" was not injected: check your FXML file 'altro.fxml'.";
        assert btnPrenota != null : "fx:id=\"btnPrenota\" was not injected: check your FXML file 'altro.fxml'.";
        assert date != null : "fx:id=\"date\" was not injected: check your FXML file 'altro.fxml'.";
        assert extra != null : "fx:id=\"extra\" was not injected: check your FXML file 'altro.fxml'.";
        assert family != null : "fx:id=\"family\" was not injected: check your FXML file 'altro.fxml'.";
        assert ospiti != null : "fx:id=\"ospiti\" was not injected: check your FXML file 'altro.fxml'.";
        assert partenza != null : "fx:id=\"partenze\" was not injected: check your FXML file 'altro.fxml'.";
        assert prenotazione != null : "fx:id=\"prenotazione\" was not injected: check your FXML file 'altro.fxml'.";
        assert txtArea != null : "fx:id=\"txtArea\" was not injected: check your FXML file 'altro.fxml'.";
        assert bar != null : "fx:id=\"bar\" was not injected: check your FXML file 'altro.fxml'.";
      
      
        txtArea.setStyle("-fx-background-color: cornsilk;");
        ospiti.getItems().clear();
		for (int i = 1; i <= 70; i++)
			ospiti.getItems().add(i);
		extra.getItems().clear();
		extra.getItems().add("STANDARD");
		extra.getItems().add("SUITE");
		partenza.valueProperty().set(GregorianCalendar.getInstance(Locale.ITALIAN));
		arrivo.valueProperty().set(GregorianCalendar.getInstance(Locale.ITALIAN));
		partenza.dateFormatProperty().set(DateFormat.getDateInstance(DateFormat.MEDIUM, Locale.ITALIAN));
		arrivo.dateFormatProperty().set(DateFormat.getDateInstance(DateFormat.MEDIUM, Locale.ITALIAN));
		prenotazione.setDisable(true);
		
		bar.setLegendVisible(false);
		
    }

	public HotelModel getHotel() {
		return hotel;
	}

	public void setHotel(HotelModel hotel) {
		this.hotel = hotel;
	}
	public void startCondition(){
		date.setDisable(false);
		partenza.valueProperty().set(GregorianCalendar.getInstance(Locale.ITALIAN));
		arrivo.valueProperty().set(GregorianCalendar.getInstance(Locale.ITALIAN));
		prenotazione.setDisable(true);
		family.clear();
		ospiti.getSelectionModel().clearSelection();
		extra.getSelectionModel().clearSelection();
	}
	public void updateChart(){
		bar.getData().clear();
		bar.setLegendVisible(false);
		int[] mesi = new int [12];
		String[] m= DateFormatSymbols.getInstance(Locale.ITALIAN).getMonths();
		
		for(int j=0;j<12;j++)
			mesi[j]=0;
		for(Reservation r : hotel.getPrenotazioni().values()){
		
			if(r.getArrival().getYear()==GregorianCalendar.getInstance().getTime().getYear()){
				if(r.getArrival().getMonth()==r.getDeparture().getMonth()){
					
					mesi[r.getArrival().getMonth()]+=(r.getDeparture().getTime()-r.getArrival().getTime())/( 24 * 60 * 60 * 1000)*r.getRoom().getPrice();
				}
				else{
					Date a =new Date (r.getArrival().getTime());
					Date b = new Date(r.getDeparture().getTime());

					while (a.getMonth()==r.getArrival().getMonth()){
						mesi[r.getArrival().getMonth()]+=r.getRoom().getPrice();
						a.setDate(a.getDate()+1);
					}
					
					while (b.getMonth()==r.getDeparture().getMonth()){
						mesi[r.getDeparture().getMonth()]+=r.getRoom().getPrice();
						b.setDate(b.getDate()-1);						
					}
					
				}
			}
		} 
	
		
		XYChart.Series s = new XYChart.Series();
		
		for (int i =0;i<12;i++){

        	s.getData().add(new XYChart.Data(m[i],mesi[i]));
        
        }
		bar.getData().add(s);
        }
}
