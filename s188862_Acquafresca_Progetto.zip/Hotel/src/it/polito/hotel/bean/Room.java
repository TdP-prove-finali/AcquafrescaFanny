package it.polito.hotel.bean;

public class Room implements Comparable<Room>{
	private String idCamera;
	private int letti;
	public enum RoomEnum {STANDARD,SUITE}
	private RoomEnum tipo;
	private double price;
	

	public Room(String idCamera, int letti, String tipo) {
		this.idCamera=idCamera;
		this.letti=letti;
		this.tipo=RoomEnum.valueOf(tipo);
		if(tipo.toUpperCase().compareTo("STANDARD")==0)
			this.price=20.0*letti;
		if(tipo.toUpperCase().compareTo("SUITE")==0)
			this.price=30.0*letti;
	}

	public String getIdCamera() {
		return idCamera;
	}

	public void setIdCamera(String idCamera) {
		this.idCamera = idCamera;
	}

	public int getLetti() {
		return letti;
	}

	public void setLetti(int letti) {
		this.letti = letti;
	}



	public RoomEnum getTipo() {
		return tipo;
	}

	public void setTipo(RoomEnum tipo) {
		this.tipo = tipo;
	}


	public void setPrice(double price) {
		this.price = price;
	}

	public double getPrice() {
		// TODO Auto-generated method stub
		return  price;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idCamera == null) ? 0 : idCamera.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Room other = (Room) obj;
		 if (!idCamera.equals(other.idCamera))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return ""+idCamera;
	}

	@Override
	public int compareTo(Room a) {
		// TODO Auto-generated method stub
		return this.letti-a.getLetti();
	}
}
