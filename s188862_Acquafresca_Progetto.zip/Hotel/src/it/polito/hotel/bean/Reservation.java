package it.polito.hotel.bean;

import java.sql.Date;

public class Reservation {

	private int id;
	private String family;
	private Date arrival;
	private Date departure;
	private Room room;
	private double totalPrice;
	
	public Reservation(int id, String family, Date arrival, Date departure,
			Room room) {
		super();
		this.id = id;
		this.family = family;
		this.arrival = arrival;
		this.departure = departure;
		this.room = room;
		totalPrice= ((departure.getTime()-arrival.getTime())/( 24 * 60 * 60 * 1000))* room.getPrice();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFamily() {
		return family;
	}

	public void setFamily(String family) {
		this.family = family;
	}

	public Date getArrival() {
		return arrival;
	}

	public void setArrival(Date arrival) {
		this.arrival = arrival;
	}

	public Date getDeparture() {
		return departure;
	}

	public void setDeparture(Date departure) {
		this.departure = departure;
	}

	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Reservation other = (Reservation) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Reservation [id=" + id + ", family=" + family + ", arrival="
				+ arrival + ", departure=" + departure + ", room=" + room + "]";
	}
	
	
}
