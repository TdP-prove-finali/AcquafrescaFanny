package it.polito.hotel;

import it.polito.hotel.bean.Reservation;
import it.polito.hotel.bean.Room;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class HotelModel {
	
	
	private Map<String,Room>camere;
	private static int idRes = 0;
	private Map<Integer,Reservation> prenotazioni;
	
	
	public HotelModel() {
		camere = new HashMap<>();
		prenotazioni = new HashMap<>();
	}
	public Map<String, Room> getCamere() {
		return camere;
	}
	public void setCamere(Map<String, Room> camere) {
		this.camere = camere;
	}
	
	
	public void setPrenotazioni(Map<Integer, Reservation> prenotazioni) {
		this.prenotazioni = prenotazioni;
	}
	public Map<Integer, Reservation> getPrenotazioni() {
		return prenotazioni;
	}

	public List<Reservation> addPrenotazione(String family, Date arrival,
			Date departure, int persone, String extra) {
		int totPosLib = 0;
		List<Room> free = calcolaFree(arrival, departure);
		List<Reservation> temp = new LinkedList<>();
		if (!free.isEmpty()) {
			if (persone < 63) {
				for (Room r : free) {
					if (r.getTipo().toString().equals(extra))
						totPosLib += r.getLetti();
				}
				if (persone <= totPosLib) {
					
						List<Room> assegnate = assegnaCamere(free, persone,
								extra);
						if (!assegnate.isEmpty()) {
							for (Room t : assegnate) {
								Reservation a = new Reservation(idRes, family,
										arrival, departure, t);
								temp.add(a);
								prenotazioni.put(idRes, a);

								idRes++;

							}
						}
					}
			} else {
				
				for (Room r : free) {
					totPosLib += r.getLetti();
				}
				if (persone <= totPosLib) {
					List<Room> assegnate = assegnaCamere(free, persone);
					if (!assegnate.isEmpty()) {
						for (Room t : assegnate) {
							Reservation a = new Reservation(idRes, family,
									arrival, departure, t);
							temp.add(a);
							prenotazioni.put(idRes, a);

							idRes++;

						}
					}
				}
			}
		}
		return temp;
	}

	private List<Room> assegnaCamere(List<Room> free, int persone) {
		List<Room> assegnate = new LinkedList<>();
		Collections.sort(free, new Comparator<Room>() {
			@Override
			public int compare(Room a, Room a1) {
				return -(a.getLetti() - a1.getLetti());
			}

		});
		int res = persone;
		while (res > 0) {
			Room temp = null;
			int avanzo = 0;
			int i = 0;
			for (Room a : free) {

				if (res >= a.getLetti()&& avanzo==0)
					
					if (res - a.getLetti() >= 2 || res - a.getLetti() == 0) {
						
						temp = a;
						break;
					}

				if(res<a.getLetti()) {
					
					if (avanzo == 0) {
						temp = a;
						avanzo = a.getLetti() - res;
						
					}
					if ((i = a.getLetti() - res) < avanzo) {
						avanzo = i;
						temp = a;

					}
				}
			}

			assegnate.add(temp);
			res -= temp.getLetti();
			free.remove(free.indexOf(temp));

		}

		return assegnate;

	}
	
	private List<Room> assegnaCamere(List<Room> free, int persone, String extra) {
		List<Room> assegnate = new LinkedList<>();
		Collections.sort(free, new Comparator<Room>() {
			@Override
			public int compare(Room a, Room a1) {
				return -(a.getLetti() - a1.getLetti());
			}

		});
		int res = persone;
		while (res > 0) {
			Room temp = null;
			int avanzo = 0;
			int i = 0;
			for (Room a : free) {

				if (a.getTipo().toString().equals(extra)) {
					if (res >= a.getLetti() && avanzo==0) {
					
						if (res - a.getLetti() >= 2 || res - a.getLetti() == 0) {

							temp = a;
							break;
						}
					}
				if(res<a.getLetti()){
						if (avanzo == 0) {
							temp = a;
							avanzo = a.getLetti() - res;
						}
						if ((i = a.getLetti() - res) < avanzo) {
							avanzo = i;
							temp = a;

						}
						
					}

				}
			}
			
			assegnate.add(temp);
			res -= temp.getLetti();
			free.remove(free.indexOf(temp));

		
		}

		return assegnate;

	}

	public List<Room> calcolaFree(Date da, Date a) {

		List<Room> allFreeRooms = new LinkedList<Room>(this.getCamere()
				.values());

		if (!this.getPrenotazioni().isEmpty()) {

			List<Reservation> allRes = new ArrayList<Reservation>(this
					.getPrenotazioni().values());
			for (Reservation res : allRes) {
				if (res.getArrival().equals(da)) {
					allFreeRooms.remove(res.getRoom());

				}
				if (res.getArrival().after(da) && !res.getArrival().equals(da)
						&& res.getArrival().before(a)) {
					allFreeRooms.remove(res.getRoom());

				}
				if (res.getArrival().before(da) && res.getDeparture().after(da)
						&& !res.getDeparture().equals(da)) {
					allFreeRooms.remove(res.getRoom());

				}
			}
		}

		return allFreeRooms;
	}
	public static int getIdRes() {
		return idRes;
	}
	public static void setIdRes(int idRes) {
		HotelModel.idRes = idRes;
	}
}
