package it.polito.hotel;

import java.io.IOException;
import java.sql.Date;
import java.util.LinkedList;
import java.util.List;


import it.polito.hotel.bean.Room;
import it.polito.hotel.dao.HotelDAO;
import it.polito.hotel.gui.Controller;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class HotelMain extends Application {

	
	public void start(Stage primaryStage) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("gui/hotel.fxml"));
		
		Parent main = (Parent) loader.load();
		
		
		HotelModel hotel = new HotelModel();
		caricaAlbergo(hotel);
		
		
		Controller c = loader.getController();
		
		c.setHotel(hotel);
		
		
		Scene view =new Scene(main);
		view.setFill(Color.CORNSILK);
		primaryStage.setTitle("Hotel Reservation");
		primaryStage.setScene(view);
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
		
	}
	public void caricaAlbergo(HotelModel m){
		HotelDAO dao = new HotelDAO();
		m.setCamere(dao.GetAllRooms());
		List<Room>temp = new LinkedList<>(m.getCamere().values());
		m.setPrenotazioni(dao.GetAllReservation(temp));
		m.setIdRes(m.getPrenotazioni().size()+2);
		
	}
}
