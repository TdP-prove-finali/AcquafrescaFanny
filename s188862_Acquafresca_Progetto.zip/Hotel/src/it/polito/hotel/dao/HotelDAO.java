package it.polito.hotel.dao;


import it.polito.hotel.bean.Reservation;
import it.polito.hotel.bean.Room;
import it.polito.hotel.db.DBConnect;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class HotelDAO {
	public Map <Integer,Reservation> GetAllReservation(List<Room>camere) {
		final String sql = "SELECT * FROM reservations ORDER BY id ASC";
		Map<Integer,Reservation> m = new TreeMap<>();

		try {
			Connection conn = DBConnect.getInstance().getConnection();
			PreparedStatement st = conn.prepareStatement(sql);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				Room temp = camere.get(camere.indexOf(new Room(rs.getString("room").toUpperCase(),0,rs.getString("extra"))));
				
				m.put(rs.getInt("id"),new Reservation(rs.getInt("id"),rs.getString("family"),
								rs.getDate("arrival"), rs.getDate("departure"),temp));
				
			}
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		return m;
	}
	public Map<String, Room> GetAllRooms() {
		final String sql = "SELECT * FROM rooms";
		Map<String, Room> m = new HashMap<String,Room>();

		try {
			Connection conn = DBConnect.getInstance().getConnection();
			PreparedStatement st = conn.prepareStatement(sql);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				m.put(rs.getString("idRoom"),
						new Room(rs.getString("idRoom").toUpperCase(), rs.getInt("letti"), rs.getString("tipo")));
			}
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		return m;
	}
	public void addReservation(Reservation i) {
		final String sql = "INSERT INTO RESERVATIONS (id,family,arrival,departure,extra,room) VALUES (?,?,?,?,?,?)";
		

		try {
			Connection conn = DBConnect.getInstance().getConnection();
			PreparedStatement st = conn.prepareStatement(sql);
				st.setInt(1, i.getId());
	            st.setString(2, i.getFamily());
	            st.setDate(3, i.getArrival());
	            st.setDate(4, i.getDeparture());
	            st.setString(5,i.getRoom().getTipo().toString());
	            st.setString(6,i.getRoom().getIdCamera());
	            st.executeUpdate();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		
	}
	/*public GregorianCalendar cambiaData(Date d){
		String s = d.toString();
		int year=Integer.parseInt(s.substring(0,4));
		int month=Integer.parseInt(s.substring(5,7));
		int day=Integer.parseInt(s.substring(8,10));
		GregorianCalendar g=new GregorianCalendar(year,month,day);
		System.out.println(g.get(g.YEAR));
		return g;
		
	}*/
}
